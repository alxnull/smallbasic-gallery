-SBCraft v0.3-
Programmed by Ardiezc Quazhulu
Original idea by Notch (Minecraft).
-----------------------------------------
>Extract "SBCraft.zip" to Local Disc "C:\". Nowhere else!
>Feel free to edit and mod. Please post your edits in a reply to my original post.
>Feel free to comment and suggest features that I can add in to the game.
>Please do not give yourself all credit!
-Thanks Small Basic/Forum Members!-
(+.[ ].+) 

(Included with game is a Minecraft wallpaper pack changer. Enjoy!)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Change Log
---------------
v0.1
>Basic Movement
>Place 1 Block

v0.2
>New Character
>4 Blocks
>Better Help Interface
>Better Block Placement

v0.3
>Changed gameboard and Object size.
>Fixed step size.
>Added Background Change
>Added Credits