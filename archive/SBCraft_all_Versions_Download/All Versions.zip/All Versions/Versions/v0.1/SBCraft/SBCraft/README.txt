-SBCraft v0.1-
Programmed by Ardiezc Quazhulu
Original idea by Notch (Minecraft).
-----------------------------------------
>Feel free to edit and mod. Please post your edits in a reply to my original post.
>Feel free to comment and suggest features that I can add in to the game.
>Please do not give yourself all credit! (Add your name to the credits list below.)
-Thanks Small Basic/Forum Members!-
(+.[ ].+) 

(Included with game is a Minecraft wallpaper pack changer. Enjoy!)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-CREDITS-
(Just add your name and save this file)
>ardiezc_quazhulu
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
>
