Program Name - Shooting Game v1.1
Type - Simple
v1.1
* Avoided double erase of Images.
* Shooting curser moves perfectly.

A Simple Shooting game to understand the concept of collision.

Needs To Be Compiled Before Running, Because it needs LD Extension.

Contents

1) sb file - shooting game without images
2) pdb file - shooting game without images
3) exe file - shooting game without images

1) sb file - shooting game with images
2) pdb file - shooting game with images
3) exe file - shooting game with  images
4) png file - untitled

Controls

--Left or Right mouse button to shoot

--Any key To Show score
