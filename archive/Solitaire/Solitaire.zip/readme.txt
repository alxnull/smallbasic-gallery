Solitaire 1.0 released on 18 March 2016 by Jibba Jabba.
Uses X-Extension and Litdev Extension.

Available from:
http://getjibba.com/gallery/index.php#Solitaire
Or
https://gallery.technet.microsoft.com/Solitaire-efeccf5a



